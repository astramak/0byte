-- phpMyAdmin SQL Dump
-- version 3.1.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июн 07 2009 г., 21:37
-- Версия сервера: 5.1.34
-- Версия PHP: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `0byte`
--

-- --------------------------------------------------------

--
-- Структура таблицы `answ`
--

CREATE TABLE IF NOT EXISTS `answ` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `val` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=41 ;

-- --------------------------------------------------------

--
-- Структура таблицы `blogs`
--

CREATE TABLE IF NOT EXISTS `blogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `owner` text COLLATE utf8_unicode_ci NOT NULL,
  `ratep` int(11) NOT NULL DEFAULT '0',
  `ratem` int(11) NOT NULL DEFAULT '0',
  `av` text COLLATE utf8_unicode_ci NOT NULL,
  `about` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Структура таблицы `brate`
--

CREATE TABLE IF NOT EXISTS `brate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `who` text COLLATE utf8_unicode_ci NOT NULL,
  `pid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Структура таблицы `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` text COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `who` text COLLATE utf8_unicode_ci NOT NULL,
  `cid` int(11) NOT NULL,
  `ratep` int(11) NOT NULL DEFAULT '0',
  `ratem` int(11) NOT NULL DEFAULT '0',
  `lvl` int(11) NOT NULL DEFAULT '0',
  `krnl` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=579 ;

-- --------------------------------------------------------

--
-- Структура таблицы `crate`
--

CREATE TABLE IF NOT EXISTS `crate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `who` text COLLATE utf8_unicode_ci NOT NULL,
  `pid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=60 ;

-- --------------------------------------------------------

--
-- Структура таблицы `eye`
--

CREATE TABLE IF NOT EXISTS `eye` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `who` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=256 ;

-- --------------------------------------------------------

--
-- Структура таблицы `hist`
--

CREATE TABLE IF NOT EXISTS `hist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `who` text COLLATE utf8_unicode_ci NOT NULL,
  `pid` int(11) NOT NULL,
  `date` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=64 ;

-- --------------------------------------------------------

--
-- Структура таблицы `inblog`
--

CREATE TABLE IF NOT EXISTS `inblog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blogid` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `bname` text COLLATE utf8_unicode_ci NOT NULL,
  `out` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Структура таблицы `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `url` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pm`
--

CREATE TABLE IF NOT EXISTS `pm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auth` text COLLATE utf8_unicode_ci NOT NULL,
  `to` text COLLATE utf8_unicode_ci NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `date` text COLLATE utf8_unicode_ci NOT NULL,
  `readed` int(11) NOT NULL DEFAULT '0',
  `dto` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

-- --------------------------------------------------------

--
-- Структура таблицы `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` text COLLATE utf8_unicode_ci NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `auth` text COLLATE utf8_unicode_ci NOT NULL,
  `ratep` int(11) NOT NULL,
  `ratem` int(11) NOT NULL,
  `ftext` text COLLATE utf8_unicode_ci NOT NULL,
  `blog` text COLLATE utf8_unicode_ci NOT NULL,
  `blogid` int(11) NOT NULL,
  `tag` text COLLATE utf8_unicode_ci NOT NULL,
  `lock` int(11) NOT NULL DEFAULT '0',
  `blck` tinyint(4) NOT NULL DEFAULT '0',
  `tp` tinyint(4) NOT NULL DEFAULT '0',
  `lnk` text COLLATE utf8_unicode_ci NOT NULL,
  `flw` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=96 ;

-- --------------------------------------------------------

--
-- Структура таблицы `rate`
--

CREATE TABLE IF NOT EXISTS `rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `who` text COLLATE utf8_unicode_ci NOT NULL,
  `pid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=30 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `num` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=234 ;

-- --------------------------------------------------------

--
-- Структура таблицы `urate`
--

CREATE TABLE IF NOT EXISTS `urate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `who` text COLLATE utf8_unicode_ci NOT NULL,
  `pid` text COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=69 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mail` text COLLATE utf8_unicode_ci NOT NULL,
  `icq` text COLLATE utf8_unicode_ci NOT NULL,
  `jabber` text COLLATE utf8_unicode_ci NOT NULL,
  `site` text COLLATE utf8_unicode_ci NOT NULL,
  `lvl` int(11) NOT NULL,
  `pwd` text COLLATE utf8_unicode_ci NOT NULL,
  `ratep` int(11) NOT NULL DEFAULT '0',
  `ratem` int(11) NOT NULL DEFAULT '0',
  `about` text COLLATE utf8_unicode_ci NOT NULL,
  `av` text COLLATE utf8_unicode_ci NOT NULL,
  `frnd` text COLLATE utf8_unicode_ci NOT NULL,
  `lck` tinyint(4) NOT NULL DEFAULT '0',
  `hml` int(11) NOT NULL,
  `activ` int(11) NOT NULL DEFAULT '1',
  `ref` int(11) NOT NULL DEFAULT '0',
  `postre` tinyint(4) NOT NULL DEFAULT '1',
  `comre` tinyint(4) NOT NULL DEFAULT '1',
  `pmre` tinyint(4) NOT NULL DEFAULT '1',
  `online` text COLLATE utf8_unicode_ci NOT NULL,
  `prate` int(11) NOT NULL DEFAULT '0',
  `crate` int(11) NOT NULL DEFAULT '0',
  `brate` int(11) NOT NULL DEFAULT '0',
  `juse` tinyint(4) NOT NULL DEFAULT '0',
  `jdate` text COLLATE utf8_unicode_ci NOT NULL,
  `jtext` text COLLATE utf8_unicode_ci NOT NULL,
  `jname` text COLLATE utf8_unicode_ci NOT NULL,
  `jabre` tinyint(4) NOT NULL DEFAULT '0',
  `city` tinytext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;

-- --------------------------------------------------------

--
-- Структура таблицы `wansw`
--

CREATE TABLE IF NOT EXISTS `wansw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `who` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=48 ;
